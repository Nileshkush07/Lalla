package com.dollop.adda;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DemomvcApplication {

	public static void main(String[] args) {
		SpringApplication.run(DemomvcApplication.class, args);
	}

}
