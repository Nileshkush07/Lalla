package com.dollop.adda.Repo;

public interface EmpRepo {

}
