package com.dollop.app.task;

import org.springframework.context.annotation.ComponentScan;

@ComponentScan("com.dollop.app.task")
public class MyConfig {

}
